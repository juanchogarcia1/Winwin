Instrucciones para subir el sitio:

1. Ve a github.com y crea un nuevo repositorio (por ejemplo, win-win-2.0).
2. Sube todos estos archivos directamente al repositorio.
3. Activa GitHub Pages desde Settings > Pages.
4. Selecciona la rama 'main' y carpeta '/'.
5. Listo, tu sitio estará publicado con la URL que te da GitHub Pages.
